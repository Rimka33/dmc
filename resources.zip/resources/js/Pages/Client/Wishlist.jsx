import React, { useContext } from 'react';
import MainLayout from '../../Layouts/MainLayout';
import { Link } from 'react-router-dom';
import { WishlistContext } from '../../contexts/WishlistContext';
import { CartContext } from '../../contexts/CartContext';
import { Heart, Trash2 } from 'lucide-react';

export default function Wishlist() {
    const { wishlist, loading, removeFromWishlist } = useContext(WishlistContext);
    const { addToCart } = useContext(CartContext);

    const handleAddToCart = async (product) => {
        const result = await addToCart(product.id, 1);
        if (result.success) {
            removeFromWishlist(product.id);
        } else {
            alert(result.message);
        }
    };

    return (
        <MainLayout>
            <div className="py-24 relative overflow-hidden" style={{ background: 'linear-gradient(to bottom, rgba(1, 26, 10, 1), rgba(5, 128, 49, 1)), url(/images/wishlist-bg.jpg) center/cover' }}>
                <div className="container mx-auto px-4 text-center relative z-10">
                    <h1 className="text-5xl md:text-6xl font-black text-neon-green uppercase mb-6 tracking-tighter italic">MA LISTE DE SOUHAITS</h1>
                    <div className="flex items-center justify-center gap-3 text-white text-sm font-bold tracking-widest uppercase bg-white/5 py-3 px-6 rounded-full inline-flex border border-white/10">
                        <Link to="/" className="hover:text-neon-green transition-colors">Accueil</Link>
                        <span className="text-gray-500">/</span>
                        <span className="text-neon-green">Wishlist</span>
                    </div>
                </div>
            </div>

            <section className="py-24 bg-white">
                <div className="container mx-auto px-4">
                    {loading ? (
                        <div className="flex justify-center py-24">
                            <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-forest-green"></div>
                        </div>
                    ) : wishlist.length > 0 ? (
                        <div className="max-w-6xl mx-auto">
                            <div className="bg-white rounded-[2.5rem] shadow-2xl shadow-gray-200/50 border border-gray-100 overflow-hidden">
                                <table className="w-full text-left">
                                    <thead className="bg-gray-50 border-b border-gray-100">
                                        <tr>
                                            <th className="px-8 py-6 text-[10px] font-black uppercase tracking-widest text-gray-400">Produit</th>
                                            <th className="px-8 py-6 text-[10px] font-black uppercase tracking-widest text-gray-400">Prix</th>
                                            <th className="px-8 py-6 text-[10px] font-black uppercase tracking-widest text-gray-400">Statut Stock</th>
                                            <th className="px-8 py-6 text-[10px] font-black uppercase tracking-widest text-gray-400">Actions</th>
                                            <th className="px-8 py-6"></th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-100">
                                        {wishlist.map((item) => {
                                            const product = item.product || item; // Depend sur le format du backend Resource
                                            return (
                                                <tr key={item.id} className="group hover:bg-gray-50/50 transition-colors">
                                                    <td className="px-8 py-6">
                                                        <div className="flex items-center gap-6">
                                                            <div className="w-20 h-20 bg-gray-50 rounded-2xl p-2 flex-shrink-0">
                                                                <img
                                                                    src={product.primary_image || '/images/products/default.png'}
                                                                    alt={product.name}
                                                                    onError={(e) => { e.target.src = '/images/products/default.png'; }}
                                                                    className="w-full h-full object-contain"
                                                                />
                                                            </div>
                                                            <div>
                                                                <Link to={`/produit/${product.id}`} className="font-black text-gray-900 hover:text-forest-green transition-colors text-lg uppercase tracking-tight">
                                                                    {product.name}
                                                                </Link>
                                                                <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mt-1">{product.category_name || 'Informatique'}</p>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td className="px-8 py-6">
                                                        <span className="text-xl font-black text-forest-green font-mono">{product.price_formatted}</span>
                                                    </td>
                                                    <td className="px-8 py-6">
                                                        <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${product.stock_quantity > 0 ? 'bg-neon-green/10 text-forest-green' : 'bg-red-50 text-red-500'}`}>
                                                            {product.stock_quantity > 0 ? 'En Stock' : 'Rupture'}
                                                        </span>
                                                    </td>
                                                    <td className="px-8 py-6">
                                                        <button
                                                            onClick={() => handleAddToCart(product)}
                                                            disabled={product.stock_quantity <= 0}
                                                            className="px-6 py-3 bg-gray-900 text-white font-black text-[10px] uppercase tracking-widest rounded-xl hover:bg-forest-green transition-all shadow-lg active:scale-95 disabled:opacity-30"
                                                        >
                                                            Ajouter au panier
                                                        </button>
                                                    </td>
                                                    <td className="px-8 py-6 text-right">
                                                        <button
                                                            onClick={() => removeFromWishlist(product.id)}
                                                            className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 hover:bg-red-50 hover:text-red-500 transition-all"
                                                        >
                                                            <Trash2 className="w-5 h-5" />
                                                        </button>
                                                    </td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    ) : (
                        <div className="text-center py-24 max-w-md mx-auto">
                            <div className="w-24 h-24 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-8 shadow-inner">
                                <Heart className="w-12 h-12 text-gray-200" />
                            </div>
                            <h2 className="text-3xl font-black text-gray-900 uppercase italic tracking-tighter mb-4">Votre liste est vide</h2>
                            <p className="text-gray-500 font-medium mb-10 leading-relaxed">
                                Vous n'avez pas encore de produits coup de cœur. Parcourez notre catalogue pour trouver les meilleures offres.
                            </p>
                            <Link to="/shop" className="inline-block px-10 py-5 bg-forest-green text-white font-black uppercase rounded-2xl hover:bg-dark-green transition-all shadow-xl shadow-forest-green/20">
                                Continuer mes achats
                            </Link>
                        </div>
                    )}
                </div>
            </section>
        </MainLayout>
    );
}
