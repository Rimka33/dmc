import React from 'react';
import AdminLayout from '../../../Layouts/AdminLayout';
import { useForm, Link } from '@inertiajs/react';
import { ArrowLeft, Save, AlertCircle } from 'lucide-react';

export default function Edit({ category }) {
    const { data, setData, put, processing, errors } = useForm({
        name: category.name || '',
        slug: category.slug || '',
        description: category.description || '',
        icon: category.icon || '',
        image: category.image || '',
        order: category.order || 0,
        is_active: category.is_active ?? true,
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        put(`/admin/categories/${category.id}`);
    };

    return (
        <AdminLayout>
            <div className="max-w-4xl mx-auto space-y-6">
                <div className="flex items-center justify-between">
                    <div>
                        <Link href="/admin/categories" className="flex items-center gap-1 text-gray-500 hover:text-forest-green mb-2 text-sm">
                            <ArrowLeft size={16} /> Retour à la liste
                        </Link>
                        <h1 className="text-2xl font-bold text-gray-900">Modifier la Catégorie</h1>
                    </div>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-2">
                                <label className="text-sm font-semibold text-gray-700">Nom de la catégorie *</label>
                                <input
                                    type="text"
                                    value={data.name}
                                    onChange={(e) => setData('name', e.target.value)}
                                    className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-neon-green outline-none transition-all ${errors.name ? 'border-red-500' : 'border-gray-200'
                                        }`}
                                    required
                                />
                                {errors.name && <p className="text-xs text-red-500 flex items-center gap-1"><AlertCircle size={12} /> {errors.name}</p>}
                            </div>

                            <div className="space-y-2">
                                <label className="text-sm font-semibold text-gray-700">Slug *</label>
                                <input
                                    type="text"
                                    value={data.slug}
                                    onChange={(e) => setData('slug', e.target.value)}
                                    className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-neon-green outline-none transition-all ${errors.slug ? 'border-red-500' : 'border-gray-200'
                                        }`}
                                    required
                                />
                                {errors.slug && <p className="text-xs text-red-500 flex items-center gap-1"><AlertCircle size={12} /> {errors.slug}</p>}
                            </div>
                        </div>

                        <div className="space-y-2">
                            <label className="text-sm font-semibold text-gray-700">Description</label>
                            <textarea
                                value={data.description}
                                onChange={(e) => setData('description', e.target.value)}
                                rows="4"
                                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-neon-green outline-none transition-all"
                            ></textarea>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-2">
                                <label className="text-sm font-semibold text-gray-700">Ordre d'affichage</label>
                                <input
                                    type="number"
                                    value={data.order}
                                    onChange={(e) => setData('order', e.target.value)}
                                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-neon-green outline-none transition-all"
                                />
                            </div>

                            <div className="flex items-center gap-2 pt-8">
                                <input
                                    type="checkbox"
                                    id="is_active"
                                    checked={data.is_active}
                                    onChange={(e) => setData('is_active', e.target.checked)}
                                    className="w-4 h-4 text-forest-green rounded border-gray-300 focus:ring-neon-green"
                                />
                                <label htmlFor="is_active" className="text-sm font-semibold text-gray-700 cursor-pointer">Actif</label>
                            </div>
                        </div>
                    </div>

                    <div className="flex justify-end gap-4">
                        <Link
                            href="/admin/categories"
                            className="px-6 py-2 border border-gray-200 text-gray-600 rounded-lg hover:bg-gray-50 font-semibold transition-all"
                        >
                            Annuler
                        </Link>
                        <button
                            type="submit"
                            disabled={processing}
                            className="px-6 py-2 bg-forest-green text-white rounded-lg hover:bg-dark-green font-bold shadow-lg shadow-forest-green/20 flex items-center gap-2 transition-all disabled:opacity-50"
                        >
                            <Save size={20} />
                            {processing ? 'Enregistrement...' : 'Mettre à jour la catégorie'}
                        </button>
                    </div>
                </form>
            </div>
        </AdminLayout>
    );
}
